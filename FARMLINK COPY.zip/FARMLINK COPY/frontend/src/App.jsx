import { useCallback, useEffect, useState } from "react";
import "./App.css";

const API_URL = "http://localhost:5000";

function App() {
  // ==================================================
  // AUTH STATE
  // ==================================================

  const [showLogin, setShowLogin] = useState(false);
  const [showRegister, setShowRegister] = useState(false);

  const [currentUser, setCurrentUser] = useState(() => {
    const savedUser = localStorage.getItem("farmlinkUser");
    return savedUser ? JSON.parse(savedUser) : null;
  });

  const [loginData, setLoginData] = useState({
    email: "",
    password: ""
  });

  const [registerData, setRegisterData] = useState({
    name: "",
    email: "",
    password: "",
    role: "farmer",
    phone: "",
    farm_name: "",
    location: "",
    state: "",
    crops: "",
    land_area: ""
  });

  const [message, setMessage] = useState("");


  // ==================================================
  // CROP STATE
  // ==================================================

  const [crops, setCrops] = useState([]);

  const [showAddCrop, setShowAddCrop] = useState(false);
  const [showEditCrop, setShowEditCrop] = useState(false);
  const [editingCropId, setEditingCropId] = useState(null);

  const [cropMessage, setCropMessage] = useState("");

  const [cropData, setCropData] = useState({
    crop_name: "",
    quantity: "",
    unit: "kg",
    expected_price: "",
    description: ""
  });

  // ==================================================
  // MARKETPLACE STATE
  // ==================================================

  const [showMarketplace, setShowMarketplace] = useState(false);

  const [marketplaceCrops, setMarketplaceCrops] = useState([]);

  const [marketplaceSearch, setMarketplaceSearch] = useState("");

  const [marketplaceLoading, setMarketplaceLoading] = useState(false);

  const [marketplaceMessage, setMarketplaceMessage] = useState("");

  const [selectedMarketplaceCrop, setSelectedMarketplaceCrop] =
    useState(null);

  // ==================================================
  // PURCHASE REQUEST STATE
  // ==================================================

  const [showPurchaseRequest, setShowPurchaseRequest] =
    useState(false);

  const [purchaseRequestData, setPurchaseRequestData] =
    useState({
      quantity: "",
      offered_price: "",
      message: ""
    });

  const [purchaseMessage, setPurchaseMessage] =
    useState("");

  const [purchaseLoading, setPurchaseLoading] =
    useState(false);

  // Purchase request dashboard state
  const [purchaseRequests, setPurchaseRequests] = useState([]);
  const [requestsLoading, setRequestsLoading] = useState(false);
  const [requestsMessage, setRequestsMessage] = useState("");
  const [requestActionLoading, setRequestActionLoading] = useState(null);

  // Keep the same dashboard layout, but show role-specific features.
  const isBuyer = String(currentUser?.role || "").toLowerCase() === "buyer";
  const isFarmer = !isBuyer;


  // ==================================================
  // LOGIN
  // ==================================================

  const handleLogin = async (e) => {
    e.preventDefault();

    setMessage("Logging in...");

    try {
      const response = await fetch(
        `${API_URL}/api/auth/login`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify(loginData)
        }
      );

      const data = await response.json();

      if (data.success) {
        localStorage.setItem(
          "farmlinkUser",
          JSON.stringify(data.user)
        );

        setCurrentUser(data.user);

        setShowLogin(false);
        setMessage("");

        setLoginData({
          email: "",
          password: ""
        });
      } else {
        setMessage(data.message);
      }

    } catch (error) {
      console.error("Login error:", error);

      setMessage(
        "Unable to connect to FarmLink server."
      );
    }
  };


  // ==================================================
  // REGISTER
  // ==================================================

  const handleRegister = async (e) => {
    e.preventDefault();

    setMessage("Creating account...");

    try {
      const response = await fetch(
        `${API_URL}/api/auth/register`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify(registerData)
        }
      );

      const data = await response.json();

      if (data.success) {

        setMessage(
          "Account created successfully! 🎉"
        );

        setTimeout(() => {

          setShowRegister(false);
          setShowLogin(true);

          setLoginData({
            email: registerData.email,
            password: ""
          });

          setMessage("");

        }, 1200);

      } else {
        setMessage(data.message);
      }

    } catch (error) {

      console.error(
        "Registration error:",
        error
      );

      setMessage(
        "Unable to connect to FarmLink server."
      );
    }
  };


  // ==================================================
  // LOGOUT
  // ==================================================

  const handleLogout = () => {

    localStorage.removeItem(
      "farmlinkUser"
    );

    setCurrentUser(null);
    setCrops([]);
    setMessage("");
  };


  // ==================================================
  // GET FARMER ID
  // ==================================================

  const getFarmerId = () => {
    return (
      currentUser?.id ||
      currentUser?.user_id ||
      currentUser?.userId
    );
  };


  // ==================================================
  // LOAD CROPS
  // ==================================================

  const loadCrops = async () => {

    const farmerId = getFarmerId();

    if (!farmerId) {
      console.log("Farmer ID not found.");
      return;
    }

    try {

      const response = await fetch(
        `${API_URL}/api/crops/farmer/${farmerId}`
      );

      const data = await response.json();

      if (data.success) {

        setCrops(data.crops || []);

      } else {

        console.error(
          "Could not load crops:",
          data.message
        );

      }

    } catch (error) {

      console.error(
        "Load crops error:",
        error
      );

    }
  };


  // ==================================================
  // LOAD CROPS WHEN FARMER LOGS IN
  // ==================================================

  useEffect(() => {

    if (!currentUser) {
      return;
    }

    const farmerId =
      currentUser?.id ||
      currentUser?.user_id ||
      currentUser?.userId;

    if (!farmerId) {
      console.log("Farmer ID not found.");
      return;
    }

    const fetchCrops = async () => {
      try {
        const response = await fetch(
          `${API_URL}/api/crops/farmer/${farmerId}`
        );

        const data = await response.json();

        if (data.success) {
          setCrops(data.crops || []);
        } else {
          console.error(
            "Could not load crops:",
            data.message
          );
        }

      } catch (error) {
        console.error(
          "Load crops error:",
          error
        );
      }
    };

    fetchCrops();

  }, [currentUser]);


  // ==================================================
  // ADD CROP
  // ==================================================

  const handleAddCrop = async (e) => {

    e.preventDefault();

    setCropMessage("Saving crop...");

    const farmerId = getFarmerId();

    if (!farmerId) {

      setCropMessage(
        "Farmer ID not found. Please login again."
      );

      return;
    }

    try {

      const response = await fetch(
        `${API_URL}/api/crops/add`,
        {
          method: "POST",

          headers: {
            "Content-Type": "application/json"
          },

          body: JSON.stringify({
            farmer_id: farmerId,
            crop_name: cropData.crop_name,
            quantity: cropData.quantity,
            unit: cropData.unit,
            expected_price:
              cropData.expected_price || null,
            description:
              cropData.description || null
          })
        }
      );

      const data = await response.json();

      if (data.success) {

        setCropMessage(
          "Crop added successfully! 🌾"
        );

        setCropData({
          crop_name: "",
          quantity: "",
          unit: "kg",
          expected_price: "",
          description: ""
        });

        await loadCrops();

        setTimeout(() => {
          setShowAddCrop(false);
          setCropMessage("");
        }, 1000);

      } else {

        setCropMessage(
          data.message ||
          "Crop could not be added."
        );

      }

    } catch (error) {

      console.error(
        "Add crop error:",
        error
      );

      setCropMessage(
        "Unable to connect to FarmLink server."
      );
    }
  };


  // ==================================================
  // OPEN EDIT CROP
  // ==================================================

  const openEditCrop = (crop) => {
    setEditingCropId(crop.id);

    setCropData({
      crop_name: crop.crop_name || "",
      quantity: crop.quantity ?? "",
      unit: crop.unit || "kg",
      expected_price: crop.expected_price ?? "",
      description: crop.description || ""
    });

    setCropMessage("");
    setShowEditCrop(true);
  };


  // ==================================================
  // UPDATE CROP
  // ==================================================

  const handleUpdateCrop = async (e) => {
    e.preventDefault();

    if (!editingCropId) {
      setCropMessage("Crop ID not found.");
      return;
    }

    setCropMessage("Updating crop...");

    try {
      const response = await fetch(
        `${API_URL}/api/crops/${editingCropId}`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            crop_name: cropData.crop_name.trim(),
            quantity: cropData.quantity,
            unit: cropData.unit,
            expected_price:
              cropData.expected_price || null,
            description:
              cropData.description.trim() || null
          })
        }
      );

      const data = await response.json();

      if (data.success) {
        setCropMessage("Crop updated successfully! ✅");
        await loadCrops();

        setTimeout(() => {
          setShowEditCrop(false);
          setEditingCropId(null);
          setCropMessage("");
        }, 800);
      } else {
        setCropMessage(
          data.message || "Crop could not be updated."
        );
      }
    } catch (error) {
      console.error("Update crop error:", error);
      setCropMessage(
        "Unable to connect to FarmLink server."
      );
    }
  };


  // ==================================================
  // DELETE CROP
  // ==================================================

  const handleDeleteCrop = async (cropId) => {
    const confirmDelete = window.confirm(
      "Are you sure you want to delete this crop?"
    );

    if (!confirmDelete) {
      return;
    }

    try {
      const response = await fetch(
        `${API_URL}/api/crops/${cropId}`,
        {
          method: "DELETE"
        }
      );

      const data = await response.json();

      if (data.success) {
        setCrops((previousCrops) =>
          previousCrops.filter(
            (crop) => crop.id !== cropId
          )
        );
      } else {
        alert(
          data.message ||
          "Crop could not be deleted."
        );
      }
    } catch (error) {
      console.error("Delete crop error:", error);
      alert(
        "Unable to connect to FarmLink server."
      );
    }
  };


  // ==================================================
  // LOAD MARKETPLACE CROPS
  // ==================================================

  const loadMarketplaceCrops = async (search = "") => {

    setMarketplaceLoading(true);
    setMarketplaceMessage("");

    try {

      const endpoint = search.trim()
        ? `${API_URL}/api/marketplace/search?q=${encodeURIComponent(search.trim())}`
        : `${API_URL}/api/marketplace/crops`;

      const response = await fetch(endpoint);

      const data = await response.json();

      if (data.success) {

        setMarketplaceCrops(data.crops || []);

      } else {

        setMarketplaceMessage(
          data.message ||
          "Could not load marketplace."
        );

      }

    } catch (error) {

      console.error(
        "Marketplace error:",
        error
      );

      setMarketplaceMessage(
        "Unable to connect to FarmLink server."
      );

    } finally {

      setMarketplaceLoading(false);

    }
  };


  // ==================================================
  // OPEN MARKETPLACE
  // ==================================================

  const openMarketplace = async () => {

    setMarketplaceSearch("");
    setSelectedMarketplaceCrop(null);
    setMarketplaceMessage("");
    setShowMarketplace(true);

    await loadMarketplaceCrops("");

  };


  // ==================================================
  // SEARCH MARKETPLACE
  // ==================================================

  const handleMarketplaceSearch = async (e) => {

    e.preventDefault();

    await loadMarketplaceCrops(
      marketplaceSearch
    );

  };


  // ==================================================
  // OPEN PURCHASE REQUEST
  // ==================================================

  const openPurchaseRequest = (crop) => {

    setSelectedMarketplaceCrop(crop);

    setPurchaseRequestData({
      quantity: "",
      offered_price:
        crop.expected_price || "",
      message: ""
    });

    setPurchaseMessage("");

    setShowPurchaseRequest(true);
  };


  // ==================================================
  // SEND PURCHASE REQUEST
  // ==================================================

  const handlePurchaseRequest = async (e) => {

    e.preventDefault();

    if (!currentUser?.id) {

      setPurchaseMessage(
        "Please login as a buyer first."
      );

      return;
    }

    if (!selectedMarketplaceCrop) {

      setPurchaseMessage(
        "Please select a crop."
      );

      return;
    }

    setPurchaseLoading(true);
    setPurchaseMessage("");

    try {

      const response = await fetch(
        `${API_URL}/api/purchase/create`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({

            crop_id:
              selectedMarketplaceCrop.id,

            buyer_id:
              currentUser.id,

            quantity:
              purchaseRequestData.quantity,

            offered_price:
              purchaseRequestData.offered_price ||
              null,

            message:
              purchaseRequestData.message ||
              null

          })
        }
      );

      const data = await response.json();

      if (data.success) {

        setPurchaseMessage(
          "Purchase request sent successfully! ✅"
        );

        setPurchaseRequestData({
          quantity: "",
          offered_price: "",
          message: ""
        });

      } else {

        setPurchaseMessage(
          data.message ||
          "Purchase request failed."
        );

      }

    } catch (error) {

      console.error(
        "Purchase request error:",
        error
      );

      setPurchaseMessage(
        "Unable to connect to FarmLink server."
      );

    } finally {

      setPurchaseLoading(false);

    }
  };


  // ==================================================
  // PURCHASE REQUEST DASHBOARD
  // ==================================================

  const loadPurchaseRequests = useCallback(async () => {
    const userId =
      currentUser?.id ??
      currentUser?.user_id ??
      currentUser?.userId;

    if (!userId) {
      setPurchaseRequests([]);
      setRequestsMessage("");
      return;
    }

    setRequestsLoading(true);
    setRequestsMessage("");

    const role = String(currentUser?.role || "").toLowerCase();
    const endpoint =
      role === "buyer"
        ? `${API_URL}/api/purchase/buyer/${userId}`
        : `${API_URL}/api/purchase/farmer/${userId}`;

    try {
      const response = await fetch(endpoint);
      const data = await response.json();

      if (!response.ok || !data.success) {
        setPurchaseRequests([]);
        setRequestsMessage(
          data.message || "Could not load purchase requests."
        );
        return;
      }

      setPurchaseRequests(
        Array.isArray(data.requests) ? data.requests : []
      );
    } catch (error) {
      console.error("Load purchase requests error:", error);
      setPurchaseRequests([]);
      setRequestsMessage("Unable to connect to FarmLink server.");
    } finally {
      setRequestsLoading(false);
    }
  }, [currentUser]);

  const updatePurchaseRequestStatus = useCallback(async (requestId, action) => {
    if (!["accept", "reject"].includes(action)) {
      return;
    }

    setRequestActionLoading(requestId);
    setRequestsMessage("");

    try {
      const response = await fetch(
        `${API_URL}/api/purchase/${requestId}/${action}`,
        { method: "PUT" }
      );
      const data = await response.json();

      if (!response.ok || !data.success) {
        setRequestsMessage(
          data.message || `Could not ${action} this request.`
        );
        return;
      }

      setRequestsMessage(
        data.message || `Request ${action}ed successfully.`
      );
      await loadPurchaseRequests();
    } catch (error) {
      console.error(`Purchase request ${action} error:`, error);
      setRequestsMessage("Unable to connect to FarmLink server.");
    } finally {
      setRequestActionLoading(null);
    }
  }, [loadPurchaseRequests]);

  useEffect(() => {
    if (currentUser) {
      void loadPurchaseRequests();
    }
  }, [currentUser, loadPurchaseRequests]);

  // ==================================================
  // FARMER DASHBOARD
  // ==================================================

  if (currentUser) {

    return (
      <div className="dashboard-page">

        {/* ================= NAVBAR ================= */}

        <nav className="dashboard-navbar">

          <div className="logo">
            🌾 Farm<span>Link</span>
          </div>

          <div className="dashboard-user">

            <div className="user-avatar">
              {currentUser.name
                ?.charAt(0)
                ?.toUpperCase()}
            </div>

            <div className="user-info">

              <strong>
                {currentUser.name}
              </strong>

              <span>
                {currentUser.role}
              </span>

            </div>

            <button
              className="logout-btn"
              onClick={handleLogout}
            >
              Logout
            </button>

          </div>

        </nav>


        {/* ================= DASHBOARD ================= */}

        <main className="dashboard-content">

          {/* ================= WELCOME ================= */}

          <div className="dashboard-welcome">

            <div>

              <p className="dashboard-label">
                {isBuyer
                  ? "BUYER DASHBOARD"
                  : "FARMER DASHBOARD"}
              </p>

              <h1>
                Welcome back,{" "}
                {currentUser.name} 👋
              </h1>

              <p>
                {isBuyer
                  ? "Track your purchase requests and explore available crops."
                  : "Here's an overview of your farm information."}
              </p>

            </div>

          </div>


          {/* ================= STAT CARDS ================= */}

          <div className="dashboard-stats" style={{ display: isBuyer ? "none" : undefined }}>

            <div className="dashboard-stat">

              <div className="stat-icon">
                🌾
              </div>

              <div>

                <span>
                  Crops
                </span>

                <strong>
                  {crops.length}
                </strong>

              </div>

            </div>


            <div className="dashboard-stat">

              <div className="stat-icon">
                📐
              </div>

              <div>

                <span>
                  Land Area
                </span>

                <strong>
                  {currentUser.land_area ||
                    "0"}
                </strong>

                <small>
                  acres
                </small>

              </div>

            </div>


            <div className="dashboard-stat">

              <div className="stat-icon">
                📍
              </div>

              <div>

                <span>
                  Location
                </span>

                <strong>
                  {currentUser.location ||
                    "Not added"}
                </strong>

              </div>

            </div>


            <div className="dashboard-stat">

              <div className="stat-icon">
                🤖
              </div>

              <div>

                <span>
                  AI Prediction
                </span>

                <strong>
                  Ready
                </strong>

              </div>

            </div>

          </div>


          {/* ================= FARM + CROPS ================= */}

          <div className="dashboard-grid" style={{ display: isBuyer ? "none" : undefined }}>


            {/* ================= FARM INFORMATION ================= */}

            <section className="dashboard-card farm-details">

              <div className="card-heading">

                <div>

                  <p>
                    MY FARM
                  </p>

                  <h2>
                    Farm Information
                  </h2>

                </div>

                <span className="verified-badge">
                  ✓ Registered
                </span>

              </div>


              <div className="details-list">

                <div className="detail-row">

                  <span>
                    Farm Name
                  </span>

                  <strong>
                    {currentUser.farm_name ||
                      "Not provided"}
                  </strong>

                </div>


                <div className="detail-row">

                  <span>
                    Farmer
                  </span>

                  <strong>
                    {currentUser.name}
                  </strong>

                </div>


                <div className="detail-row">

                  <span>
                    Email
                  </span>

                  <strong>
                    {currentUser.email}
                  </strong>

                </div>


                <div className="detail-row">

                  <span>
                    Phone
                  </span>

                  <strong>
                    {currentUser.phone ||
                      "Not provided"}
                  </strong>

                </div>


                <div className="detail-row">

                  <span>
                    Location
                  </span>

                  <strong>
                    {currentUser.location ||
                      "Not provided"}
                  </strong>

                </div>


                <div className="detail-row">

                  <span>
                    State
                  </span>

                  <strong>
                    {currentUser.state ||
                      "Not provided"}
                  </strong>

                </div>


                <div className="detail-row">

                  <span>
                    Land Area
                  </span>

                  <strong>
                    {currentUser.land_area ||
                      "Not provided"}

                    {currentUser.land_area
                      ? " acres"
                      : ""}
                  </strong>

                </div>

              </div>

            </section>


            {/* ================= MY CROPS ================= */}

            <section className="dashboard-card">

              <div className="card-heading">

                <div>
                  <p>MY CROPS</p>
                  <h2>Listed Crops</h2>
                </div>

                <button
                  type="button"
                  onClick={loadCrops}
                  title="Refresh crops"
                  style={{
                    border: "none",
                    background: "#eef5ea",
                    color: "#2f6b3b",
                    borderRadius: "10px",
                    padding: "9px 12px",
                    cursor: "pointer",
                    fontWeight: "700"
                  }}
                >
                  ↻ Refresh
                </button>

              </div>

              <div className="crop-list">

                {crops.length > 0 ? (
                  crops.map((crop) => (
                    <div
                      className="crop-item"
                      key={crop.id}
                      style={{
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "space-between",
                        gap: "14px"
                      }}
                    >

                      <div
                        style={{
                          display: "flex",
                          alignItems: "flex-start",
                          gap: "12px",
                          minWidth: 0
                        }}
                      >
                        <span style={{ fontSize: "24px" }}>
                          🌾
                        </span>

                        <div style={{ minWidth: 0 }}>
                          <strong>
                            {crop.crop_name}
                          </strong>

                          <div
                            style={{
                              fontSize: "13px",
                              marginTop: "5px",
                              opacity: "0.72",
                              lineHeight: "1.5"
                            }}
                          >
                            Quantity: {crop.quantity} {crop.unit}
                            {crop.expected_price !== null &&
                            crop.expected_price !== undefined &&
                            crop.expected_price !== ""
                              ? ` • Expected: ₹${crop.expected_price}/kg`
                              : ""}
                          </div>

                          {crop.description && (
                            <div
                              style={{
                                fontSize: "12px",
                                marginTop: "4px",
                                opacity: "0.62"
                              }}
                            >
                              {crop.description}
                            </div>
                          )}
                        </div>
                      </div>

                      <div
                        style={{
                          display: "flex",
                          gap: "7px",
                          flexShrink: 0
                        }}
                      >
                        <button
                          type="button"
                          onClick={() => openEditCrop(crop)}
                          style={{
                            border: "none",
                            background: "#eef5ea",
                            color: "#2f6b3b",
                            borderRadius: "8px",
                            padding: "8px 10px",
                            cursor: "pointer",
                            fontWeight: "600"
                          }}
                        >
                          Edit
                        </button>

                        <button
                          type="button"
                          onClick={() => handleDeleteCrop(crop.id)}
                          style={{
                            border: "none",
                            background: "#fbecec",
                            color: "#b42318",
                            borderRadius: "8px",
                            padding: "8px 10px",
                            cursor: "pointer",
                            fontWeight: "600"
                          }}
                        >
                          Delete
                        </button>
                      </div>

                    </div>
                  ))
                ) : (
                  <div className="empty-state">
                    <span>🌱</span>
                    <p>No crops added yet.</p>
                    <small>
                      Click “Add Crop” below to list your first crop.
                    </small>
                  </div>
                )}

              </div>

            </section>

          </div>


          {/* ================= QUICK ACTIONS ================= */}

          <section className="quick-actions">

            <div className="section-title">

              <p>
                {isBuyer ? "BUYER TOOLS" : "QUICK ACTIONS"}
              </p>

              <h2>
                {isBuyer ? "Find Crops and Track Requests" : "Manage Your Farm"}
              </h2>

            </div>


            <div className="action-grid">


              {/* ADD CROP — FARMER ONLY */}
              {!isBuyer && (
              <button
                className="action-card"
                onClick={() => {
                  setShowAddCrop(true);
                  setCropMessage("");
                }}
              >

                <span>
                  🌾
                </span>

                <div>

                  <strong>
                    Add Crop
                  </strong>

                  <small>
                    List a new agricultural crop
                  </small>

                </div>

                <b>
                  →
                </b>

              </button>
              )}


              {/* AI PRICE PREDICTION — FUTURE FEATURE, NOT ACTIVE */}

              <button
                className="action-card"
                onClick={() =>
                  alert(
                    "AI Price Prediction is planned as a future feature and is not available yet."
                  )
                }
              >

                <span>
                  🤖
                </span>

                <div>

                  <strong>
                    AI Price Prediction (Coming Soon)
                  </strong>

                  <small>
                    Planned future feature
                  </small>

                </div>

                <b>
                  →
                </b>

              </button>


              {/* MARKETPLACE — AVAILABLE TO BOTH ROLES */}

              <button
                className="action-card"
                onClick={openMarketplace}
              >

                <span>
                  🛒
                </span>

                <div>

                  <strong>
                    {isBuyer ? "Browse Marketplace" : "Marketplace"}
                  </strong>

                  <small>
                    {isBuyer
                      ? "Find crops and send purchase requests"
                      : "Explore available crops and buyers"}
                  </small>

                </div>

                <b>
                  →
                </b>

              </button>

            </div>

          </section>

          {/* ================= PURCHASE REQUESTS ================= */}
          <section className="quick-actions" style={{ marginTop: "28px" }}>
            <div className="section-title">
              <p>
                {isBuyer
                  ? "BUYER ACTIVITY"
                  : "BUYER ENQUIRIES"}
              </p>
              <h2>
                {isBuyer
                  ? "My Purchase Requests"
                  : "Purchase Requests Received"}
              </h2>
              <p style={{ marginTop: "8px" }}>
                {isBuyer
                  ? "Track the status of requests you have submitted."
                  : "Review requests buyers have sent for your crop listings."}
              </p>
              <button
                type="button"
                onClick={loadPurchaseRequests}
                disabled={requestsLoading}
                style={{
                  marginTop: "12px",
                  padding: "9px 14px",
                  border: "none",
                  borderRadius: "9px",
                  background: "#eef5ea",
                  color: "#2f6b3b",
                  fontWeight: 700,
                  cursor: requestsLoading ? "wait" : "pointer"
                }}
              >
                {requestsLoading ? "Refreshing..." : "Refresh Requests"}
              </button>
            </div>

            {requestsMessage && (
              <p className="auth-message" role="status">
                {requestsMessage}
              </p>
            )}

            {requestsLoading ? (
              <div className="empty-state">
                <p>Loading purchase requests...</p>
              </div>
            ) : purchaseRequests.length === 0 ? (
              <div className="empty-state">
                <span>📨</span>
                <p>No purchase requests yet.</p>
                <small>
                  {isBuyer
                    ? "Your submitted requests will appear here."
                    : "Requests for your crops will appear here."}
                </small>
              </div>
            ) : (
              <div
                className="action-grid"
                style={{
                  gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))",
                  alignItems: "stretch"
                }}
              >
                {purchaseRequests.map((request) => {
                  const status = String(request.status || "pending").toLowerCase();
                  const isBuyer =
                    String(currentUser.role || "").toLowerCase() === "buyer";

                  return (
                    <article
                      className="feature-card"
                      key={request.id}
                      style={{ textAlign: "left", minWidth: 0 }}
                    >
                      <div
                        style={{
                          display: "flex",
                          justifyContent: "space-between",
                          alignItems: "flex-start",
                          gap: "10px"
                        }}
                      >
                        <h3 style={{ marginTop: 0, marginBottom: "12px" }}>
                          {request.crop_name || "Crop listing"}
                        </h3>
                        <span
                          style={{
                            padding: "5px 9px",
                            borderRadius: "20px",
                            fontSize: "12px",
                            fontWeight: 700,
                            whiteSpace: "nowrap",
                            background:
                              status === "accepted"
                                ? "#e5f6e8"
                                : status === "rejected"
                                ? "#fde8e7"
                                : "#fff4d6",
                            color:
                              status === "accepted"
                                ? "#216e39"
                                : status === "rejected"
                                ? "#a12622"
                                : "#8a5a00"
                          }}
                        >
                          {status.toUpperCase()}
                        </span>
                      </div>

                      <p><strong>Quantity:</strong> {request.quantity} {request.unit || "kg"}</p>
                      <p>
                        <strong>Expected price:</strong>{" "}
                        {request.expected_price != null
                          ? `₹${request.expected_price}`
                          : "Not specified"}
                      </p>
                      <p>
                        <strong>{isBuyer ? "Farmer" : "Buyer"}:</strong>{" "}
                        {isBuyer
                          ? request.farmer_name || "Not provided"
                          : request.buyer_name || "Not provided"}
                      </p>
                      <p>
                        <strong>Offered price:</strong>{" "}
                        {request.offered_price != null
                          ? `₹${request.offered_price}`
                          : "No offer"}
                      </p>
                      {request.message && (
                        <p><strong>Message:</strong> {request.message}</p>
                      )}
                      <small style={{ opacity: 0.7 }}>
                        Request #{request.id}
                        {request.created_at
                          ? ` · ${new Date(request.created_at).toLocaleDateString()}`
                          : ""}
                      </small>

                      {!isBuyer && status === "pending" && (
                        <div style={{ display: "flex", gap: "10px", marginTop: "14px" }}>
                          <button
                            type="button"
                            disabled={requestActionLoading === request.id}
                            onClick={() =>
                              updatePurchaseRequestStatus(request.id, "accept")
                            }
                            style={{
                              flex: 1,
                              padding: "10px",
                              border: 0,
                              borderRadius: "8px",
                              background: "#2f6b3b",
                              color: "#fff",
                              fontWeight: 700,
                              cursor: "pointer"
                            }}
                          >
                            {requestActionLoading === request.id
                              ? "Please wait..."
                              : "Accept"}
                          </button>
                          <button
                            type="button"
                            disabled={requestActionLoading === request.id}
                            onClick={() =>
                              updatePurchaseRequestStatus(request.id, "reject")
                            }
                            style={{
                              flex: 1,
                              padding: "10px",
                              border: 0,
                              borderRadius: "8px",
                              background: "#fbecec",
                              color: "#b42318",
                              fontWeight: 700,
                              cursor: "pointer"
                            }}
                          >
                            Reject
                          </button>
                        </div>
                      )}
                    </article>
                  );
                })}
              </div>
            )}
          </section>

        </main>


        {/* ==================================================
            MARKETPLACE MODAL
        ================================================== */}

        {showMarketplace && (
          <div
            className="modal-overlay"
            style={{ zIndex: 1003 }}
          >
            <div
              className="auth-modal"
              style={{
                maxWidth: "900px",
                width: "94%",
                maxHeight: "90vh",
                overflowY: "auto"
              }}
            >

              <button
                className="close-btn"
                type="button"
                onClick={() => {
                  setShowMarketplace(false);
                  setSelectedMarketplaceCrop(null);
                  setMarketplaceMessage("");
                }}
              >
                ×
              </button>

              <div className="auth-icon">
                🛒
              </div>

              <h2>
                FarmLink Marketplace
              </h2>

              <p className="auth-subtitle">
                Explore agricultural crops listed by farmers
              </p>


              {/* SEARCH */}

              <form
                onSubmit={handleMarketplaceSearch}
                style={{
                  display: "flex",
                  gap: "10px",
                  marginBottom: "22px"
                }}
              >

                <input
                  type="text"
                  placeholder="Search crop, location or state..."
                  value={marketplaceSearch}
                  onChange={(e) =>
                    setMarketplaceSearch(
                      e.target.value
                    )
                  }
                  style={{
                    flex: 1,
                    marginBottom: 0
                  }}
                />

                <button
                  type="submit"
                  className="auth-submit"
                  style={{
                    width: "auto",
                    padding: "12px 20px",
                    marginTop: 0
                  }}
                  disabled={marketplaceLoading}
                >
                  {marketplaceLoading
                    ? "Searching..."
                    : "Search"}
                </button>

              </form>


              <div
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  marginBottom: "14px"
                }}
              >

                <strong>
                  {marketplaceCrops.length} crop
                  {marketplaceCrops.length !== 1
                    ? "s"
                    : ""} available
                </strong>

                <button
                  type="button"
                  onClick={() =>
                    loadMarketplaceCrops(
                      marketplaceSearch
                    )
                  }
                  style={{
                    border: "none",
                    background: "#eef5ea",
                    color: "#2f6b3b",
                    borderRadius: "9px",
                    padding: "8px 12px",
                    cursor: "pointer",
                    fontWeight: "700"
                  }}
                >
                  ↻ Refresh
                </button>

              </div>


              {marketplaceMessage && (
                <p className="auth-message">
                  {marketplaceMessage}
                </p>
              )}


              {/* CROP LIST */}

              {!marketplaceLoading &&
                marketplaceCrops.length === 0 ? (

                <div
                  className="empty-state"
                  style={{
                    padding: "35px 10px"
                  }}
                >
                  <span>
                    🌱
                  </span>

                  <p>
                    No crops found.
                  </p>

                  <small>
                    Try another crop name or location.
                  </small>
                </div>

              ) : (

                <div
                  style={{
                    display: "grid",
                    gridTemplateColumns:
                      "repeat(auto-fit, minmax(250px, 1fr))",
                    gap: "14px"
                  }}
                >

                  {marketplaceCrops.map((crop) => (

                    <div
                      key={crop.id}
                      style={{
                        border:
                          "1px solid #dce8d7",
                        borderRadius: "14px",
                        padding: "17px",
                        background: "#ffffff",
                        boxShadow:
                          "0 4px 14px rgba(0,0,0,0.04)"
                      }}
                    >

                      <div
                        style={{
                          display: "flex",
                          justifyContent:
                            "space-between",
                          alignItems: "flex-start",
                          gap: "10px"
                        }}
                      >

                        <div>

                          <div
                            style={{
                              fontSize: "25px"
                            }}
                          >
                            🌾
                          </div>

                          <h3
                            style={{
                              margin:
                                "5px 0 0"
                            }}
                          >
                            {crop.crop_name}
                          </h3>

                        </div>

                        <span
                          style={{
                            fontSize: "12px",
                            padding:
                              "5px 8px",
                            borderRadius:
                              "20px",
                            background:
                              "#eef5ea",
                            color:
                              "#2f6b3b",
                            fontWeight:
                              "700"
                          }}
                        >
                          Available
                        </span>

                      </div>


                      <div
                        style={{
                          marginTop: "14px",
                          lineHeight: "1.8",
                          fontSize: "14px"
                        }}
                      >

                        <div>
                          📦 <strong>Quantity:</strong>{" "}
                          {crop.quantity}{" "}
                          {crop.unit}
                        </div>

                        <div>
                          💰 <strong>Price:</strong>{" "}
                          {crop.expected_price !==
                          null &&
                          crop.expected_price !==
                          undefined &&
                          crop.expected_price !== ""
                            ? `₹${crop.expected_price}/kg`
                            : "Not specified"}
                        </div>

                        <div>
                          👨‍🌾 <strong>Farmer:</strong>{" "}
                          {crop.farmer_name ||
                            "Farmer"}
                        </div>

                        <div>
                          📍 <strong>Location:</strong>{" "}
                          {crop.farm_location ||
                            crop.farm_state ||
                            "Not specified"}
                        </div>

                      </div>


                      {crop.description && (
                        <p
                          style={{
                            fontSize: "13px",
                            opacity: 0.68,
                            margin:
                              "10px 0 0",
                            lineHeight: "1.5"
                          }}
                        >
                          {crop.description}
                        </p>
                      )}


                      <button
                        type="button"
                        onClick={() =>
                          setSelectedMarketplaceCrop(
                            crop
                          )
                        }
                        style={{
                          width: "100%",
                          marginTop: "14px",
                          border: "none",
                          background:
                            "#2f6b3b",
                          color: "#fff",
                          borderRadius:
                            "9px",
                          padding: "11px",
                          cursor:
                            "pointer",
                          fontWeight:
                            "700"
                        }}
                      >
                        View Details →
                      </button>

                    </div>

                  ))}

                </div>

              )}


              {/* DETAILS */}

              {selectedMarketplaceCrop && (
                <div
                  style={{
                    marginTop: "20px",
                    padding: "18px",
                    borderRadius: "13px",
                    background: "#f4f8f1",
                    border:
                      "1px solid #dce8d7"
                  }}
                >

                  <div
                    style={{
                      display: "flex",
                      justifyContent:
                        "space-between",
                      alignItems: "center",
                      gap: "10px"
                    }}
                  >

                    <h3
                      style={{
                        margin: 0
                      }}
                    >
                      🌾{" "}
                      {selectedMarketplaceCrop.crop_name}
                    </h3>

                    <button
                      type="button"
                      onClick={() =>
                        setSelectedMarketplaceCrop(
                          null
                        )
                      }
                      style={{
                        border: "none",
                        background:
                          "transparent",
                        cursor: "pointer",
                        fontSize: "20px"
                      }}
                    >
                      ×
                    </button>

                  </div>


                  <div
                    style={{
                      marginTop: "12px",
                      display: "grid",
                      gridTemplateColumns:
                        "repeat(auto-fit, minmax(180px, 1fr))",
                      gap: "10px"
                    }}
                  >

                    <div>
                      <small>Farmer</small>
                      <strong
                        style={{
                          display: "block"
                        }}
                      >
                        {selectedMarketplaceCrop.farmer_name ||
                          "Not specified"}
                      </strong>
                    </div>

                    <div>
                      <small>Quantity</small>
                      <strong
                        style={{
                          display: "block"
                        }}
                      >
                        {selectedMarketplaceCrop.quantity}{" "}
                        {selectedMarketplaceCrop.unit}
                      </strong>
                    </div>

                    <div>
                      <small>Expected Price</small>
                      <strong
                        style={{
                          display: "block"
                        }}
                      >
                        {selectedMarketplaceCrop.expected_price !==
                        null &&
                        selectedMarketplaceCrop.expected_price !==
                        undefined &&
                        selectedMarketplaceCrop.expected_price !==
                        ""
                          ? `₹${selectedMarketplaceCrop.expected_price}/kg`
                          : "Not specified"}
                      </strong>
                    </div>

                    <div>
                      <small>Location</small>
                      <strong
                        style={{
                          display: "block"
                        }}
                      >
                        {selectedMarketplaceCrop.farm_location ||
                          selectedMarketplaceCrop.farm_state ||
                          "Not specified"}
                      </strong>
                    </div>

                  </div>


                  {selectedMarketplaceCrop.description && (
                    <p
                      style={{
                        marginBottom: 0,
                        marginTop: "13px",
                        opacity: 0.75
                      }}
                    >
                      {selectedMarketplaceCrop.description}
                    </p>
                  )}

                  <button
                    type="button"
                    onClick={() =>
                      openPurchaseRequest(
                        selectedMarketplaceCrop
                      )
                    }
                    disabled={
                      Number(selectedMarketplaceCrop.farmer_id) ===
                      Number(currentUser?.id)
                    }
                    style={{
                      width: "100%",
                      marginTop: "16px",
                      border: "none",
                      background:
                        Number(selectedMarketplaceCrop.farmer_id) ===
                        Number(currentUser?.id)
                          ? "#cfcfcf"
                          : "#2f6b3b",
                      color: "#fff",
                      borderRadius: "9px",
                      padding: "12px",
                      cursor:
                        Number(selectedMarketplaceCrop.farmer_id) ===
                        Number(currentUser?.id)
                          ? "not-allowed"
                          : "pointer",
                      fontWeight: "700"
                    }}
                  >
                    {Number(selectedMarketplaceCrop.farmer_id) ===
                    Number(currentUser?.id)
                      ? "Your Own Crop"
                      : "🛒 Request to Buy"}
                  </button>

                </div>
              )}

            </div>
          </div>
        )}


        {/* ==================================================
            PURCHASE REQUEST MODAL
        ================================================== */}

        {showPurchaseRequest &&
          selectedMarketplaceCrop && (
            <div
              className="modal-overlay"
              style={{ zIndex: 1005 }}
            >
              <div
                className="auth-modal"
                style={{
                  maxWidth: "520px",
                  width: "92%",
                  maxHeight: "90vh",
                  overflowY: "auto"
                }}
              >

                <button
                  className="close-btn"
                  type="button"
                  onClick={() => {
                    setShowPurchaseRequest(false);
                    setPurchaseMessage("");
                  }}
                >
                  ×
                </button>

                <div className="auth-icon">
                  🛒
                </div>

                <h2>
                  Request to Buy
                </h2>

                <p className="auth-subtitle">
                  {selectedMarketplaceCrop.crop_name}
                  {" "}from{" "}
                  {selectedMarketplaceCrop.farmer_name ||
                    "Farmer"}
                </p>


                <div
                  style={{
                    padding: "13px",
                    background: "#f4f8f1",
                    borderRadius: "10px",
                    marginBottom: "16px",
                    lineHeight: "1.7",
                    fontSize: "14px"
                  }}
                >

                  <div>
                    📦 Available:{" "}
                    <strong>
                      {selectedMarketplaceCrop.quantity}{" "}
                      {selectedMarketplaceCrop.unit}
                    </strong>
                  </div>

                  <div>
                    💰 Expected Price:{" "}
                    <strong>
                      {selectedMarketplaceCrop.expected_price
                        ? `₹${selectedMarketplaceCrop.expected_price}/kg`
                        : "Not specified"}
                    </strong>
                  </div>

                </div>


                <form
                  onSubmit={handlePurchaseRequest}
                >

                  <label>
                    Quantity to Buy
                  </label>

                  <input
                    type="number"
                    min="0.01"
                    max={selectedMarketplaceCrop.quantity}
                    step="0.01"
                    placeholder={`Maximum ${selectedMarketplaceCrop.quantity}`}
                    value={
                      purchaseRequestData.quantity
                    }
                    onChange={(e) =>
                      setPurchaseRequestData({
                        ...purchaseRequestData,
                        quantity:
                          e.target.value
                      })
                    }
                    required
                  />


                  <label>
                    Offered Price (₹ per kg)
                  </label>

                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    placeholder="Enter your offer"
                    value={
                      purchaseRequestData.offered_price
                    }
                    onChange={(e) =>
                      setPurchaseRequestData({
                        ...purchaseRequestData,
                        offered_price:
                          e.target.value
                      })
                    }
                  />


                  <label>
                    Message
                  </label>

                  <textarea
                    placeholder="Write a message to the farmer..."
                    value={
                      purchaseRequestData.message
                    }
                    onChange={(e) =>
                      setPurchaseRequestData({
                        ...purchaseRequestData,
                        message:
                          e.target.value
                      })
                    }
                    rows="4"
                    style={{
                      width: "100%",
                      boxSizing: "border-box",
                      resize: "vertical",
                      marginBottom: "15px"
                    }}
                  />


                  <button
                    type="submit"
                    className="auth-submit"
                    disabled={purchaseLoading}
                    style={{
                      opacity:
                        purchaseLoading
                          ? 0.7
                          : 1,
                      cursor:
                        purchaseLoading
                          ? "not-allowed"
                          : "pointer"
                    }}
                  >
                    {purchaseLoading
                      ? "Sending..."
                      : "Send Purchase Request →"}
                  </button>

                </form>


                {purchaseMessage && (
                  <p className="auth-message">
                    {purchaseMessage}
                  </p>
                )}

              </div>
            </div>
          )}


        {/* ==================================================
            EDIT CROP MODAL
        ================================================== */}

        {showEditCrop && (
          <div
            className="modal-overlay"
            style={{ zIndex: 1001 }}
          >
            <div
              className="auth-modal"
              style={{
                maxWidth: "520px",
                width: "92%",
                maxHeight: "90vh",
                overflowY: "auto"
              }}
            >
              <button
                className="close-btn"
                type="button"
                onClick={() => {
                  setShowEditCrop(false);
                  setEditingCropId(null);
                  setCropMessage("");
                }}
              >
                ×
              </button>

              <div className="auth-icon">✏️</div>

              <h2>Edit Crop</h2>

              <p className="auth-subtitle">
                Update your crop information
              </p>

              <form onSubmit={handleUpdateCrop}>
                <label>Crop Name</label>
                <input
                  type="text"
                  value={cropData.crop_name}
                  onChange={(e) =>
                    setCropData({
                      ...cropData,
                      crop_name: e.target.value
                    })
                  }
                  required
                />

                <label>Quantity</label>
                <input
                  type="number"
                  min="0.01"
                  step="0.01"
                  value={cropData.quantity}
                  onChange={(e) =>
                    setCropData({
                      ...cropData,
                      quantity: e.target.value
                    })
                  }
                  required
                />

                <label>Unit</label>
                <select
                  value={cropData.unit}
                  onChange={(e) =>
                    setCropData({
                      ...cropData,
                      unit: e.target.value
                    })
                  }
                >
                  <option value="kg">Kilogram (kg)</option>
                  <option value="quintal">Quintal</option>
                  <option value="ton">Ton</option>
                  <option value="litre">Litre</option>
                  <option value="piece">Piece</option>
                </select>

                <label>Expected Price (₹ per kg)</label>
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  value={cropData.expected_price}
                  onChange={(e) =>
                    setCropData({
                      ...cropData,
                      expected_price: e.target.value
                    })
                  }
                />

                <label>Description</label>
                <textarea
                  value={cropData.description}
                  onChange={(e) =>
                    setCropData({
                      ...cropData,
                      description: e.target.value
                    })
                  }
                  rows="4"
                  style={{
                    width: "100%",
                    padding: "12px",
                    border: "1px solid #d5dfd3",
                    borderRadius: "10px",
                    resize: "vertical",
                    fontFamily: "inherit",
                    boxSizing: "border-box",
                    marginBottom: "16px"
                  }}
                />

                <button
                  type="submit"
                  className="auth-submit"
                >
                  Update Crop →
                </button>
              </form>

              {cropMessage && (
                <p className="auth-message">
                  {cropMessage}
                </p>
              )}
            </div>
          </div>
        )}


        {/* ==================================================
            ADD CROP MODAL
        ================================================== */}

        {showAddCrop && (

          <div
            className="modal-overlay"
            style={{
              zIndex: 1000
            }}
          >

            <div
              className="auth-modal"
              style={{
                maxWidth: "520px",
                width: "92%",
                maxHeight: "90vh",
                overflowY: "auto"
              }}
            >

              {/* CLOSE */}

              <button
                className="close-btn"
                onClick={() => {
                  setShowAddCrop(false);
                  setCropMessage("");
                }}
              >
                ×
              </button>


              {/* ICON */}

              <div className="auth-icon">
                🌾
              </div>


              <h2>
                Add New Crop
              </h2>

              <p className="auth-subtitle">
                List your agricultural crop
              </p>


              <form
                onSubmit={handleAddCrop}
              >

                {/* CROP NAME */}

                <label>
                  Crop Name
                </label>

                <input
                  type="text"
                  placeholder="e.g. Wheat"
                  value={cropData.crop_name}
                  onChange={(e) =>
                    setCropData({
                      ...cropData,
                      crop_name:
                        e.target.value
                    })
                  }
                  required
                />


                {/* QUANTITY */}

                <label>
                  Quantity
                </label>

                <input
                  type="number"
                  min="0"
                  step="0.01"
                  placeholder="e.g. 500"
                  value={cropData.quantity}
                  onChange={(e) =>
                    setCropData({
                      ...cropData,
                      quantity:
                        e.target.value
                    })
                  }
                  required
                />


                {/* UNIT */}

                <label>
                  Unit
                </label>

                <select
                  value={cropData.unit}
                  onChange={(e) =>
                    setCropData({
                      ...cropData,
                      unit: e.target.value
                    })
                  }
                >

                  <option value="kg">
                    Kilogram (kg)
                  </option>

                  <option value="quintal">
                    Quintal
                  </option>

                  <option value="ton">
                    Ton
                  </option>

                  <option value="litre">
                    Litre
                  </option>

                  <option value="piece">
                    Piece
                  </option>

                </select>


                {/* EXPECTED PRICE */}

                <label>
                  Expected Price (₹ per kg)
                </label>

                <input
                  type="number"
                  min="0"
                  step="0.01"
                  placeholder="e.g. 28"
                  value={
                    cropData.expected_price
                  }
                  onChange={(e) =>
                    setCropData({
                      ...cropData,
                      expected_price:
                        e.target.value
                    })
                  }
                />


                {/* DESCRIPTION */}

                <label>
                  Description
                </label>

                <textarea
                  placeholder="Add some information about your crop..."
                  value={
                    cropData.description
                  }
                  onChange={(e) =>
                    setCropData({
                      ...cropData,
                      description:
                        e.target.value
                    })
                  }
                  rows="4"
                  style={{
                    width: "100%",
                    padding: "12px",
                    border:
                      "1px solid #d5dfd3",
                    borderRadius:
                      "10px",
                    resize: "vertical",
                    fontFamily:
                      "inherit",
                    boxSizing:
                      "border-box",
                    marginBottom:
                      "16px"
                  }}
                />


                {/* SUBMIT */}

                <button
                  type="submit"
                  className="auth-submit"
                >
                  Save Crop →
                </button>

              </form>


              {/* MESSAGE */}

              {cropMessage && (

                <p className="auth-message">
                  {cropMessage}
                </p>

              )}

            </div>

          </div>

        )}

      </div>
    );
  }


  // ==================================================
  // LANDING PAGE
  // ==================================================

  return (

    <div className="farmlink-page">


      {/* ================= NAVBAR ================= */}

      <nav className="navbar">

        <div className="logo">
          🌾 Farm<span>Link</span>
        </div>


        <div className="nav-links">

          <a href="#home">
            Home
          </a>

          <a href="#features">
            Features
          </a>

          <a href="#how-it-works">
            How It Works
          </a>

        </div>


        <button
          className="login-btn"
          onClick={() => {
            setShowLogin(true);
            setShowRegister(false);
            setMessage("");
          }}
        >
          Login
        </button>

      </nav>


      {/* ================= HERO ================= */}

      <section
        className="hero"
        id="home"
      >

        <div className="hero-content">

          <div className="badge">
            🌱 Digital Agriculture Marketplace
          </div>


          <h1>

            Connecting Farmers.

            <br />

            <span>
              Empowering Markets.
            </span>

          </h1>


          <p>
            FarmLink is an agricultural marketplace
            that helps farmers list crops and connect
            with buyers through a simple digital platform.
          </p>


          <div className="hero-buttons">

            <button
              className="primary-btn"
              onClick={() => {
                setShowRegister(true);
                setShowLogin(false);
                setMessage("");
              }}
            >
              Get Started →
            </button>


            <button
              className="secondary-btn"
              onClick={() =>
                document
                  .getElementById("features")
                  ?.scrollIntoView({
                    behavior: "smooth"
                  })
              }
            >
              Explore Marketplace
            </button>

          </div>

        </div>


        {/* AI CARD */}

        <div className="hero-card">

          <div className="card-icon">
            🌾
          </div>

          <h3>
            AI Price Prediction
          </h3>

          <p>
            Get estimated crop prices based
            on historical market trends.
          </p>


          <div className="price-box">

            <span>
              Predicted Price
            </span>

            <strong>
              ₹28 / KG
            </strong>

            <small>
              ↑ Estimated increase
            </small>

          </div>

        </div>

      </section>


      {/* ================= FEATURES ================= */}

      <section
        className="features"
        id="features"
      >

        <div className="section-heading">

          <p>
            WHY FARMLINK?
          </p>

          <h2>
            Everything Agriculture Needs
          </h2>

        </div>


        <div className="feature-grid">


          <div className="feature-card">

            <div>
              🌾
            </div>

            <h3>
              Verified Farmers
            </h3>

            <p>
              Only government-verified farmers
              can list agricultural products
              on the platform.
            </p>

          </div>


          <div className="feature-card">

            <div>
              🤖
            </div>

            <h3>
              AI Price Prediction
            </h3>

            <p>
              AI analyzes historical market
              data to estimate future crop prices.
            </p>

          </div>


          <div className="feature-card">

            <div>
              🛒
            </div>

            <h3>
              Authorized Marketplace
            </h3>

            <p>
              Verified farmers can connect
              with approved buyers.
            </p>

          </div>


          <div className="feature-card">

            <div>
              🏛️
            </div>

            <h3>
              Government Authorized
            </h3>

            <p>
              Government officers can verify
              users and monitor activities.
            </p>

          </div>

        </div>

      </section>


      {/* ================= HOW IT WORKS ================= */}

      <section
        className="how-it-works"
        id="how-it-works"
      >

        <div className="section-heading">

          <p>
            HOW IT WORKS
          </p>

          <h2>
            Simple. Secure. Smart.
          </h2>

        </div>


        <div className="steps">


          <div className="step">

            <div className="step-number">
              01
            </div>

            <h3>
              Get Verified
            </h3>

            <p>
              Farmers and buyers are
              verified by authorized officers.
            </p>

          </div>


          <div className="step">

            <div className="step-number">
              02
            </div>

            <h3>
              List Your Crop
            </h3>

            <p>
              Verified farmers can add
              crops and expected prices.
            </p>

          </div>


          <div className="step">

            <div className="step-number">
              03
            </div>

            <h3>
              Get AI Insights
            </h3>

            <p>
              The system provides estimated
              price predictions.
            </p>

          </div>


          <div className="step">

            <div className="step-number">
              04
            </div>

            <h3>
              Connect & Sell
            </h3>

            <p>
              Approved buyers can send
              purchase requests.
            </p>

          </div>

        </div>

      </section>


      {/* ================= FOOTER ================= */}

      <footer>

        <div className="logo">
          🌾 Farm<span>Link</span>
        </div>

        <p>
          Powered by AI • Built for Smarter Agriculture
        </p>

        <small>
          © 2026 FarmLink.
        </small>

      </footer>


      {/* ==================================================
          LOGIN MODAL
      ================================================== */}

      {showLogin && (

        <div className="modal-overlay">

          <div className="auth-modal">

            <button
              className="close-btn"
              onClick={() => {
                setShowLogin(false);
                setMessage("");
              }}
            >
              ×
            </button>


            <div className="auth-icon">
              🔐
            </div>


            <h2>
              Welcome Back
            </h2>

            <p className="auth-subtitle">
              Login to your FarmLink account
            </p>


            <form
              onSubmit={handleLogin}
            >

              <label>
                Email
              </label>

              <input
                type="email"
                placeholder="Enter your email"
                value={loginData.email}
                onChange={(e) =>
                  setLoginData({
                    ...loginData,
                    email:
                      e.target.value
                  })
                }
                required
              />


              <label>
                Password
              </label>

              <input
                type="password"
                placeholder="Enter your password"
                value={loginData.password}
                onChange={(e) =>
                  setLoginData({
                    ...loginData,
                    password:
                      e.target.value
                  })
                }
                required
              />


              <button
                type="submit"
                className="auth-submit"
              >
                Login →
              </button>

            </form>


            {message && (

              <p className="auth-message">
                {message}
              </p>

            )}


            <p className="switch-auth">

              Don't have an account?

              <button
                onClick={() => {
                  setShowLogin(false);
                  setShowRegister(true);
                  setMessage("");
                }}
              >
                Create Account
              </button>

            </p>

          </div>

        </div>

      )}


      {/* ==================================================
          REGISTER MODAL
      ================================================== */}

      {showRegister && (

        <div className="modal-overlay">

          <div className="auth-modal register-modal">

            <button
              className="close-btn"
              onClick={() => {
                setShowRegister(false);
                setMessage("");
              }}
            >
              ×
            </button>


            <div className="auth-icon">
              🌾
            </div>


            <h2>
              Create Account
            </h2>

            <p className="auth-subtitle">
              Join the FarmLink agricultural network
            </p>


            <form
              onSubmit={handleRegister}
            >

              <label>
                Full Name
              </label>

              <input
                type="text"
                placeholder="Enter your full name"
                value={registerData.name}
                onChange={(e) =>
                  setRegisterData({
                    ...registerData,
                    name:
                      e.target.value
                  })
                }
                required
              />


              <label>
                Email
              </label>

              <input
                type="email"
                placeholder="Enter your email"
                value={registerData.email}
                onChange={(e) =>
                  setRegisterData({
                    ...registerData,
                    email:
                      e.target.value
                  })
                }
                required
              />


              <label>
                Phone
              </label>

              <input
                type="tel"
                placeholder="Enter phone number"
                value={registerData.phone}
                onChange={(e) =>
                  setRegisterData({
                    ...registerData,
                    phone:
                      e.target.value
                  })
                }
                required
              />


              <label>
                Password
              </label>

              <input
                type="password"
                placeholder="Create a password"
                value={registerData.password}
                onChange={(e) =>
                  setRegisterData({
                    ...registerData,
                    password:
                      e.target.value
                  })
                }
                required
              />


              <label>
                Account Type
              </label>

              <select
                value={registerData.role}
                onChange={(e) =>
                  setRegisterData({
                    ...registerData,
                    role:
                      e.target.value
                  })
                }
              >

                <option value="farmer">
                  Farmer
                </option>

                <option value="buyer">
                  Buyer
                </option>

              </select>


              {registerData.role ===
                "farmer" && (

                <>

                  <label>
                    Farm Name
                  </label>

                  <input
                    type="text"
                    placeholder="Enter farm name"
                    value={
                      registerData.farm_name
                    }
                    onChange={(e) =>
                      setRegisterData({
                        ...registerData,
                        farm_name:
                          e.target.value
                      })
                    }
                  />


                  <label>
                    Location
                  </label>

                  <input
                    type="text"
                    placeholder="e.g. Pune"
                    value={
                      registerData.location
                    }
                    onChange={(e) =>
                      setRegisterData({
                        ...registerData,
                        location:
                          e.target.value
                      })
                    }
                  />


                  <label>
                    State
                  </label>

                  <input
                    type="text"
                    placeholder="e.g. Maharashtra"
                    value={
                      registerData.state
                    }
                    onChange={(e) =>
                      setRegisterData({
                        ...registerData,
                        state:
                          e.target.value
                      })
                    }
                  />


                  <label>
                    Crops
                  </label>

                  <input
                    type="text"
                    placeholder="e.g. Wheat, Tomato, Onion"
                    value={
                      registerData.crops
                    }
                    onChange={(e) =>
                      setRegisterData({
                        ...registerData,
                        crops:
                          e.target.value
                      })
                    }
                  />


                  <label>
                    Land Area (acres)
                  </label>

                  <input
                    type="number"
                    step="0.01"
                    placeholder="e.g. 5"
                    value={
                      registerData.land_area
                    }
                    onChange={(e) =>
                      setRegisterData({
                        ...registerData,
                        land_area:
                          e.target.value
                      })
                    }
                  />

                </>

              )}


              <button
                type="submit"
                className="auth-submit"
              >
                Create Account →
              </button>

            </form>


            {message && (

              <p className="auth-message">
                {message}
              </p>

            )}


            <p className="switch-auth">

              Already have an account?

              <button
                onClick={() => {
                  setShowRegister(false);
                  setShowLogin(true);
                  setMessage("");
                }}
              >
                Login
              </button>

            </p>

          </div>

        </div>

      )}

    </div>
  );
}

export default App;