const express = require("express");
const db = require("../db");

const router = express.Router();


// ==================================================
// GET ALL MARKETPLACE CROPS
// ==================================================

router.get("/crops", (req, res) => {

    const query = `
        SELECT
            c.id,
            c.farmer_id,
            c.crop_name,
            c.quantity,
            c.unit,
            c.expected_price,
            c.description,
            c.created_at,

            u.name AS farmer_name,
            u.phone AS farmer_phone,

            f.location AS farm_location,
            f.state AS farm_state

        FROM crops c

        LEFT JOIN users u
            ON c.farmer_id = u.id

        LEFT JOIN farmers f
            ON c.farmer_id = f.user_id

        ORDER BY c.created_at DESC
    `;


    db.query(query, (error, results) => {

        if (error) {

            console.error(
                "Marketplace crops error:",
                error.message
            );

            return res.status(500).json({
                success: false,
                message: "Could not load marketplace crops.",
                error: error.message
            });
        }


        return res.json({
            success: true,
            crops: results
        });

    });

});


// ==================================================
// SEARCH MARKETPLACE CROPS
// ==================================================

router.get("/search", (req, res) => {

    const search =
        req.query.q || "";


    const query = `
        SELECT
            c.id,
            c.farmer_id,
            c.crop_name,
            c.quantity,
            c.unit,
            c.expected_price,
            c.description,
            c.created_at,

            u.name AS farmer_name,

            f.location AS farm_location,
            f.state AS farm_state

        FROM crops c

        LEFT JOIN users u
            ON c.farmer_id = u.id

        LEFT JOIN farmers f
            ON c.farmer_id = f.user_id

        WHERE
            c.crop_name LIKE ?
            OR f.location LIKE ?
            OR f.state LIKE ?

        ORDER BY c.created_at DESC
    `;


    const searchValue =
        `%${search}%`;


    db.query(
        query,
        [
            searchValue,
            searchValue,
            searchValue
        ],
        (error, results) => {

            if (error) {

                console.error(
                    "Marketplace search error:",
                    error.message
                );

                return res.status(500).json({
                    success: false,
                    message: "Marketplace search failed.",
                    error: error.message
                });
            }


            return res.json({
                success: true,
                crops: results
            });

        }
    );

});


// ==================================================
// GET SINGLE CROP
// ==================================================

router.get("/crops/:id", (req, res) => {

    const cropId =
        req.params.id;


    const query = `
        SELECT
            c.id,
            c.farmer_id,
            c.crop_name,
            c.quantity,
            c.unit,
            c.expected_price,
            c.description,
            c.created_at,

            u.name AS farmer_name,
            u.phone AS farmer_phone,

            f.location AS farm_location,
            f.state AS farm_state

        FROM crops c

        LEFT JOIN users u
            ON c.farmer_id = u.id

        LEFT JOIN farmers f
            ON c.farmer_id = f.user_id

        WHERE c.id = ?

        LIMIT 1
    `;


    db.query(
        query,
        [cropId],
        (error, results) => {

            if (error) {

                console.error(
                    "Single crop error:",
                    error.message
                );

                return res.status(500).json({
                    success: false,
                    message: "Could not load crop.",
                    error: error.message
                });
            }


            if (results.length === 0) {

                return res.status(404).json({
                    success: false,
                    message: "Crop not found."
                });
            }


            return res.json({
                success: true,
                crop: results[0]
            });

        }
    );

});


module.exports = router;