const express = require("express");
const db = require("../db");

const router = express.Router();

/* =========================================================
   TEST ROUTE
========================================================= */

router.get("/test", (req, res) => {
    res.json({
        success: true,
        message: "Auth route is working!"
    });
});


/* =========================================================
   REGISTER
========================================================= */

router.post("/register", (req, res) => {

    console.log("\n=================================");
    console.log("REGISTER API CALLED");
    console.log("BODY:", req.body);
    console.log("=================================");

    const {
        name,
        email,
        password,
        role,
        phone,
        farm_name,
        location,
        state,
        crops,
        land_area
    } = req.body;


    /* ---------------------------------------------------------
       VALIDATION
    --------------------------------------------------------- */

    if (!name || !email || !password || !role || !phone) {

        return res.status(400).json({
            success: false,
            message: "Please fill all required fields."
        });
    }


    /* ---------------------------------------------------------
       CHECK EMAIL
       
       IMPORTANT:
       We use SELECT * instead of assuming a particular
       primary-key column name.
    --------------------------------------------------------- */

    const checkEmailSQL = `
        SELECT *
        FROM users
        WHERE email = ?
        LIMIT 1
    `;


    db.query(
        checkEmailSQL,
        [email],
        (checkError, existingUsers) => {

            if (checkError) {

                console.error(
                    "EMAIL CHECK ERROR:",
                    checkError
                );

                return res.status(500).json({
                    success: false,
                    message: "Database error while checking email.",
                    error: checkError.message,
                    code: checkError.code
                });
            }


            /* -------------------------------------------------
               EMAIL ALREADY EXISTS
            ------------------------------------------------- */

            if (existingUsers.length > 0) {

                return res.status(409).json({
                    success: false,
                    message: "Email already registered."
                });
            }


            /* -------------------------------------------------
               CREATE USER
            ------------------------------------------------- */

            const insertUserSQL = `
                INSERT INTO users
                (
                    name,
                    email,
                    password,
                    role,
                    phone
                )
                VALUES (?, ?, ?, ?, ?)
            `;


            db.query(
                insertUserSQL,
                [
                    name,
                    email,
                    password,
                    role,
                    phone
                ],
                (userError, userResult) => {

                    if (userError) {

                        console.error(
                            "USER INSERT ERROR:",
                            userError
                        );

                        return res.status(500).json({
                            success: false,
                            message: "User registration failed.",
                            error: userError.message,
                            code: userError.code
                        });
                    }


                    const userId = userResult.insertId;


                    console.log(
                        "USER CREATED:",
                        userId
                    );


                    /* =================================================
                       FARMER
                    ================================================= */

                    if (
                        String(role).toLowerCase() ===
                        "farmer"
                    ) {

                        const farmerSQL = `
                            INSERT INTO farmers
                            (
                                user_id,
                                farm_name,
                                location,
                                state,
                                crops,
                                land_area
                            )
                            VALUES (?, ?, ?, ?, ?, ?)
                        `;


                        db.query(
                            farmerSQL,
                            [
                                userId,
                                farm_name || null,
                                location || null,
                                state || null,
                                crops || null,
                                land_area
                                    ? Number(land_area)
                                    : null
                            ],
                            (farmerError) => {

                                if (farmerError) {

                                    console.error(
                                        "FARMER INSERT ERROR:",
                                        farmerError
                                    );

                                    return res.status(500).json({
                                        success: false,
                                        message:
                                            "Farmer details could not be saved.",
                                        error:
                                            farmerError.message,
                                        code:
                                            farmerError.code
                                    });
                                }


                                console.log(
                                    "FARMER DETAILS SAVED"
                                );


                                return res.status(201).json({
                                    success: true,
                                    message:
                                        "Farmer registered successfully!",
                                    userId: userId
                                });
                            }
                        );

                    } else {

                        /* ---------------------------------------------
                           BUYER
                        --------------------------------------------- */

                        return res.status(201).json({
                            success: true,
                            message:
                                "User registered successfully!",
                            userId: userId
                        });
                    }
                }
            );
        }
    );
});


/* =========================================================
   LOGIN
========================================================= */

router.post("/login", (req, res) => {

    const {
        email,
        password
    } = req.body;


    console.log("\n=================================");
    console.log("LOGIN API CALLED");
    console.log("EMAIL:", email);
    console.log("=================================");


    if (!email || !password) {

        return res.status(400).json({
            success: false,
            message: "Email and password are required."
        });
    }


    /* ---------------------------------------------------------
       GET USER

       SELECT * avoids assuming whether the ID column is
       id, user_id, etc.
    --------------------------------------------------------- */

    const loginSQL = `
        SELECT *
        FROM users
        WHERE email = ?
        LIMIT 1
    `;


    db.query(
        loginSQL,
        [email],
        (loginError, users) => {

            if (loginError) {

                console.error(
                    "LOGIN ERROR:",
                    loginError
                );

                return res.status(500).json({
                    success: false,
                    message: "Database error during login.",
                    error: loginError.message
                });
            }


            if (users.length === 0) {

                return res.status(401).json({
                    success: false,
                    message: "Invalid email or password."
                });
            }


            const user = users[0];


            /* -------------------------------------------------
               PASSWORD
            ------------------------------------------------- */

            if (user.password !== password) {

                return res.status(401).json({
                    success: false,
                    message: "Invalid email or password."
                });
            }


            /* -------------------------------------------------
               GET USER ID
               Supports common column names
            ------------------------------------------------- */

            const userId =
                user.user_id ??
                user.id ??
                user.userId;


            /* -------------------------------------------------
               FARMER
            ------------------------------------------------- */

            if (
                String(user.role).toLowerCase() ===
                "farmer"
            ) {

                const farmerSQL = `
                    SELECT *
                    FROM farmers
                    WHERE user_id = ?
                    LIMIT 1
                `;


                db.query(
                    farmerSQL,
                    [userId],
                    (farmerError, farmerRows) => {

                        if (farmerError) {

                            console.error(
                                "FARMER LOGIN ERROR:",
                                farmerError
                            );

                            return res.status(500).json({
                                success: false,
                                message:
                                    "Unable to load farmer details.",
                                error:
                                    farmerError.message
                            });
                        }


                        const farmer =
                            farmerRows.length > 0
                                ? farmerRows[0]
                                : {};


                        delete user.password;


                        return res.json({
                            success: true,
                            message:
                                "Login successful!",
                            user: {
                                ...user,
                                id: userId,
                                user_id: userId,
                                ...farmer
                            }
                        });
                    }
                );

            } else {

                delete user.password;


                return res.json({
                    success: true,
                    message:
                        "Login successful!",
                    user: {
                        ...user,
                        id: userId,
                        user_id: userId
                    }
                });
            }
        }
    );
});


/* =========================================================
   EXPORT
========================================================= */

module.exports = router;