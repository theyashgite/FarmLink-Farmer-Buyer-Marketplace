const express = require("express");
const db = require("../db");

const router = express.Router();


// ==================================================
// ADD CROP
// ==================================================

router.post("/add", (req, res) => {

    const {
        farmer_id,
        crop_name,
        quantity,
        unit,
        expected_price,
        description
    } = req.body;


    if (!farmer_id || !crop_name || !quantity) {

        return res.status(400).json({
            success: false,
            message: "Farmer ID, crop name and quantity are required."
        });
    }


    const query = `
        INSERT INTO crops
        (
            farmer_id,
            crop_name,
            quantity,
            unit,
            expected_price,
            description
        )
        VALUES (?, ?, ?, ?, ?, ?)
    `;


    db.query(
        query,
        [
            farmer_id,
            crop_name,
            quantity,
            unit || "kg",
            expected_price || null,
            description || null
        ],
        (error, result) => {

            if (error) {

                console.error(
                    "Add crop error:",
                    error.message
                );

                return res.status(500).json({
                    success: false,
                    message: "Crop could not be added."
                });
            }


            return res.status(201).json({

                success: true,

                message: "Crop added successfully!",

                cropId: result.insertId

            });

        }
    );

});


// ==================================================
// GET FARMER CROPS
// ==================================================

router.get("/farmer/:farmerId", (req, res) => {

    const farmerId =
        req.params.farmerId;


    const query = `
        SELECT
            id,
            farmer_id,
            crop_name,
            quantity,
            unit,
            expected_price,
            description,
            created_at
        FROM crops
        WHERE farmer_id = ?
        ORDER BY created_at DESC
    `;


    db.query(
        query,
        [farmerId],
        (error, results) => {

            if (error) {

                console.error(
                    "Get crops error:",
                    error.message
                );

                return res.status(500).json({
                    success: false,
                    message: "Could not fetch crops."
                });
            }


            return res.json({

                success: true,

                crops: results

            });

        }
    );

});


// ==================================================
// DELETE CROP
// ==================================================

router.delete("/:id", (req, res) => {

    const cropId =
        req.params.id;


    const query = `
        DELETE FROM crops
        WHERE id = ?
    `;


    db.query(
        query,
        [cropId],
        (error, result) => {

            if (error) {

                console.error(
                    "Delete crop error:",
                    error.message
                );

                return res.status(500).json({
                    success: false,
                    message: "Crop could not be deleted."
                });
            }


            if (result.affectedRows === 0) {

                return res.status(404).json({
                    success: false,
                    message: "Crop not found."
                });
            }


            return res.json({

                success: true,

                message: "Crop deleted successfully!"

            });

        }
    );

});


module.exports = router;