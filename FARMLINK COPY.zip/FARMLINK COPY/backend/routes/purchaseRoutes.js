const express = require("express");
const db = require("../db");

const router = express.Router();


// ==================================================
// CREATE PURCHASE REQUEST
// ==================================================

router.post("/create", (req, res) => {

    const {
        crop_id,
        buyer_id,
        quantity,
        offered_price,
        message
    } = req.body;


    // ==============================================
    // VALIDATION
    // ==============================================

    if (
        !crop_id ||
        !buyer_id ||
        !quantity
    ) {

        return res.status(400).json({
            success: false,
            message:
                "Crop ID, buyer ID and quantity are required."
        });

    }


    // ==============================================
    // FIND CROP
    // ==============================================

    const cropQuery = `
        SELECT
            id,
            farmer_id,
            crop_name,
            quantity,
            unit,
            expected_price
        FROM crops
        WHERE id = ?
        LIMIT 1
    `;


    db.query(
        cropQuery,
        [crop_id],
        (cropError, crops) => {

            if (cropError) {

                console.error(
                    "Find crop error:",
                    cropError.message
                );

                return res.status(500).json({
                    success: false,
                    message:
                        "Could not find crop."
                });

            }


            if (crops.length === 0) {

                return res.status(404).json({
                    success: false,
                    message:
                        "Crop not found."
                });

            }


            const crop = crops[0];


            // ==========================================
            // CHECK BUYER IS NOT THE FARMER
            // ==========================================

            if (
                Number(crop.farmer_id) ===
                Number(buyer_id)
            ) {

                return res.status(400).json({
                    success: false,
                    message:
                        "You cannot purchase your own crop."
                });

            }


            // ==========================================
            // CHECK QUANTITY
            // ==========================================

            if (
                Number(quantity) <= 0
            ) {

                return res.status(400).json({
                    success: false,
                    message:
                        "Quantity must be greater than zero."
                });

            }


            if (
                Number(quantity) >
                Number(crop.quantity)
            ) {

                return res.status(400).json({
                    success: false,
                    message:
                        `Only ${crop.quantity} ${crop.unit} is available.`
                });

            }


            // ==========================================
            // CHECK EXISTING PENDING REQUEST
            // ==========================================

            const existingQuery = `
                SELECT id
                FROM purchase_requests
                WHERE crop_id = ?
                AND buyer_id = ?
                AND status = 'pending'
                LIMIT 1
            `;


            db.query(
                existingQuery,
                [
                    crop_id,
                    buyer_id
                ],
                (existingError, existing) => {

                    if (existingError) {

                        console.error(
                            "Existing request error:",
                            existingError.message
                        );

                        return res.status(500).json({
                            success: false,
                            message:
                                "Could not check existing request."
                        });

                    }


                    if (existing.length > 0) {

                        return res.status(400).json({
                            success: false,
                            message:
                                "You already have a pending request for this crop."
                        });

                    }


                    // ======================================
                    // CREATE REQUEST
                    // ======================================

                    const insertQuery = `
                        INSERT INTO purchase_requests
                        (
                            crop_id,
                            buyer_id,
                            farmer_id,
                            quantity,
                            offered_price,
                            message
                        )
                        VALUES (?, ?, ?, ?, ?, ?)
                    `;


                    db.query(
                        insertQuery,
                        [
                            crop_id,
                            buyer_id,
                            crop.farmer_id,
                            quantity,
                            offered_price || null,
                            message || null
                        ],
                        (insertError, result) => {

                            if (insertError) {

                                console.error(
                                    "Create purchase request error:",
                                    insertError.message
                                );

                                return res.status(500).json({
                                    success: false,
                                    message:
                                        "Purchase request could not be created."
                                });

                            }


                            return res.status(201).json({

                                success: true,

                                message:
                                    "Purchase request sent successfully!",

                                requestId:
                                    result.insertId

                            });

                        }
                    );

                }
            );

        }
    );

});


// ==================================================
// GET BUYER REQUESTS
// ==================================================

router.get("/buyer/:buyerId", (req, res) => {

    const buyerId =
        req.params.buyerId;


    const query = `
        SELECT
            pr.id,
            pr.crop_id,
            pr.buyer_id,
            pr.farmer_id,
            pr.quantity,
            pr.offered_price,
            pr.message,
            pr.status,
            pr.created_at,

            c.crop_name,
            c.unit,
            c.expected_price,

            u.name AS farmer_name,
            u.phone AS farmer_phone

        FROM purchase_requests pr

        INNER JOIN crops c
            ON pr.crop_id = c.id

        LEFT JOIN users u
            ON pr.farmer_id = u.id

        WHERE pr.buyer_id = ?

        ORDER BY pr.created_at DESC
    `;


    db.query(
        query,
        [buyerId],
        (error, results) => {

            if (error) {

                console.error(
                    "Buyer requests error:",
                    error.message
                );

                return res.status(500).json({
                    success: false,
                    message:
                        "Could not fetch buyer requests."
                });

            }


            return res.json({

                success: true,

                requests: results

            });

        }
    );

});


// ==================================================
// GET FARMER REQUESTS
// ==================================================

router.get("/farmer/:farmerId", (req, res) => {

    const farmerId =
        req.params.farmerId;


    const query = `
        SELECT
            pr.id,
            pr.crop_id,
            pr.buyer_id,
            pr.farmer_id,
            pr.quantity,
            pr.offered_price,
            pr.message,
            pr.status,
            pr.created_at,

            c.crop_name,
            c.unit,
            c.expected_price,

            u.name AS buyer_name,
            u.phone AS buyer_phone

        FROM purchase_requests pr

        INNER JOIN crops c
            ON pr.crop_id = c.id

        LEFT JOIN users u
            ON pr.buyer_id = u.id

        WHERE pr.farmer_id = ?

        ORDER BY pr.created_at DESC
    `;


    db.query(
        query,
        [farmerId],
        (error, results) => {

            if (error) {

                console.error(
                    "Farmer requests error:",
                    error.message
                );

                return res.status(500).json({
                    success: false,
                    message:
                        "Could not fetch farmer requests."
                });

            }


            return res.json({

                success: true,

                requests: results

            });

        }
    );

});


// ==================================================
// ACCEPT REQUEST
// ==================================================

router.put("/:id/accept", (req, res) => {

    const requestId =
        req.params.id;


    const query = `
        UPDATE purchase_requests
        SET status = 'accepted'
        WHERE id = ?
        AND status = 'pending'
    `;


    db.query(
        query,
        [requestId],
        (error, result) => {

            if (error) {

                console.error(
                    "Accept request error:",
                    error.message
                );

                return res.status(500).json({
                    success: false,
                    message:
                        "Could not accept request."
                });

            }


            if (
                result.affectedRows === 0
            ) {

                return res.status(404).json({
                    success: false,
                    message:
                        "Pending request not found."
                });

            }


            return res.json({

                success: true,

                message:
                    "Purchase request accepted!"

            });

        }
    );

});


// ==================================================
// REJECT REQUEST
// ==================================================

router.put("/:id/reject", (req, res) => {

    const requestId =
        req.params.id;


    const query = `
        UPDATE purchase_requests
        SET status = 'rejected'
        WHERE id = ?
        AND status = 'pending'
    `;


    db.query(
        query,
        [requestId],
        (error, result) => {

            if (error) {

                console.error(
                    "Reject request error:",
                    error.message
                );

                return res.status(500).json({
                    success: false,
                    message:
                        "Could not reject request."
                });

            }


            if (
                result.affectedRows === 0
            ) {

                return res.status(404).json({
                    success: false,
                    message:
                        "Pending request not found."
                });

            }


            return res.json({

                success: true,

                message:
                    "Purchase request rejected!"

            });

        }
    );

});


module.exports = router;