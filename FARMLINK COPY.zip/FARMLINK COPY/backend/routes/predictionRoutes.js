const express = require("express");

const router = express.Router();

/*
==================================================
AI PRICE PREDICTION
==================================================

For now we are using a simple rule-based prediction
system. Later this endpoint can be connected to an
actual ML model.
*/

router.post("/predict", (req, res) => {

    const {
        crop_name,
        quantity,
        expected_price,
        location
    } = req.body;


    // ==============================================
    // VALIDATION
    // ==============================================

    if (!crop_name) {

        return res.status(400).json({
            success: false,
            message: "Crop name is required."
        });

    }


    // ==============================================
    // BASE PRICE
    // ==============================================

    let basePrice = Number(expected_price);


    /*
    If farmer has not entered an expected price,
    use a basic sample market price.
    */

    if (!basePrice || basePrice <= 0) {

        const crop = crop_name
            .toLowerCase()
            .trim();


        const samplePrices = {

            tomato: 28,
            onion: 32,
            potato: 25,
            wheat: 30,
            rice: 42,
            soybean: 48,
            maize: 24,
            sugarcane: 35,
            cotton: 65,
            cabbage: 22

        };


        basePrice =
            samplePrices[crop] || 30;

    }


    // ==============================================
    // SIMPLE AI-LIKE MARKET TREND
    // ==============================================

    /*
    This is intentionally simple for the first
    working version.

    Positive trend:
    predicted price increases

    Negative trend:
    predicted price decreases
    */

    const trends = [
        "up",
        "up",
        "stable",
        "up",
        "down"
    ];


    const randomTrend =
        trends[
            Math.floor(
                Math.random() * trends.length
            )
        ];


    let changePercent = 0;


    if (randomTrend === "up") {

        changePercent =
            Math.floor(
                Math.random() * 11
            ) + 5;

    }

    else if (randomTrend === "down") {

        changePercent =
            -(Math.floor(
                Math.random() * 8
            ) + 3);

    }

    else {

        changePercent = 0;

    }


    // ==============================================
    // PREDICTED PRICE
    // ==============================================

    const predictedPrice =
        basePrice +
        (basePrice * changePercent / 100);


    const roundedPrice =
        Math.round(
            predictedPrice * 100
        ) / 100;


    // ==============================================
    // RECOMMENDATION
    // ==============================================

    let recommendation;


    if (changePercent >= 5) {

        recommendation =
            "Wait — prices may increase.";

    }

    else if (changePercent <= -3) {

        recommendation =
            "Consider selling soon.";

    }

    else {

        recommendation =
            "Market looks stable.";

    }


    // ==============================================
    // RESPONSE
    // ==============================================

    return res.json({

        success: true,

        prediction: {

            crop_name,

            location:
                location || "Not specified",

            quantity:
                quantity || 0,

            current_price:
                basePrice,

            predicted_price:
                roundedPrice,

            change_percent:
                changePercent,

            trend:
                randomTrend,

            recommendation

        }

    });

});


module.exports = router;