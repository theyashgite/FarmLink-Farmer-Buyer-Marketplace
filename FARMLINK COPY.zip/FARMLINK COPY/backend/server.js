const express = require("express");
const cors = require("cors");
require("dotenv").config();

const db = require("./db");
const authRoutes = require("./routes/authRoutes");
const predictionRoutes = require("./routes/predictionRoutes");
const cropRoutes = require("./routes/cropRoutes");
const marketplaceRoutes =
    require("./routes/marketplaceRoutes");
const purchaseRoutes =
    require("./routes/purchaseRoutes");
const app = express();

const PORT = 5000;

// ==================== MIDDLEWARE ====================

app.use(
    cors({
        origin: "http://localhost:5173",
        methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
        allowedHeaders: ["Content-Type", "Authorization"]
    })
);

app.use(express.json());

// ==================== REQUEST LOGGER ====================

app.use((req, res, next) => {
    console.log(`[${req.method}] ${req.url}`);
    next();
});

// ==================== BASIC ROUTE ====================

app.get("/", (req, res) => {
    res.json({
        success: true,
        message: "🌾 FarmLink Backend is Running!"
    });
});

// ==================== DATABASE TEST ====================

app.get("/api/test-db", (req, res) => {
    db.query("SELECT 1 AS result", (err, results) => {
        if (err) {
            console.error("Database error:", err.message);

            return res.status(500).json({
                success: false,
                message: "Database connection failed"
            });
        }

        res.json({
            success: true,
            message: "FarmLink API connected to MySQL!",
            database: results[0].result === 1
        });
    });
});

// ==================== AUTH TEST ====================

app.get("/api/test-auth", (req, res) => {
    res.json({
        success: true,
        message: "FarmLink authentication API is reachable!"
    });
});

// ==================== AUTH ROUTES ====================

app.use("/api/auth", authRoutes);
app.use("/api/prediction", predictionRoutes);
app.use("/api/crops", cropRoutes);
app.use("/api/marketplace", marketplaceRoutes);
app.use(
    "/api/purchase",
    purchaseRoutes
);
// ==================== 404 ====================

app.use((req, res) => {
    res.status(404).json({
        success: false,
        message: `Route not found: ${req.method} ${req.url}`
    });
});

// ==================== SERVER ====================

app.listen(PORT, () => {
    console.log("");
    console.log("========================================");
    console.log("🌾 FarmLink Backend");
    console.log("========================================");
    console.log(`🚀 Server: http://localhost:${PORT}`);
    console.log("🔗 Frontend: http://localhost:5173");
    console.log("🗄️ MySQL: Connected through db.js");
    console.log("========================================");
    console.log("");
});